
// Load students from localStorage
function loadStudents() {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    return students;
}

// Save students to localStorage
function saveStudents(students) {
    localStorage.setItem('students', JSON.stringify(students));
}

// Render student list
function renderStudents() {
    const students = loadStudents();
    const tbody = document.getElementById('studentTable').querySelector('tbody');
    tbody.innerHTML = '';
    students.forEach((student, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.roll}</td>
            <td>${student.email}</td>
            <td><button class="action-btn" onclick="deleteStudent(${index})">Delete</button></td>
        `;
        tbody.appendChild(row);
    });
}

// Handle form submission
const form = document.getElementById('studentForm');
form.addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const roll = document.getElementById('roll').value.trim();
    const email = document.getElementById('email').value.trim();
    if (name && roll && email) {
        const students = loadStudents();
        students.push({ name, roll, email });
        saveStudents(students);
        renderStudents();
        form.reset();
    }
});

// Delete student
function deleteStudent(index) {
    let students = loadStudents();
    students.splice(index, 1);
    saveStudents(students);
    renderStudents();
}

// Initial render
renderStudents();
